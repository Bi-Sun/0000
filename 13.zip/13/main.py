from client import Qkhanh

autoreset=True
# ae gắn cookie và imei ở đây nhé file extension đẻ get cookie mik sẽ để ở bình luận
imei = ""

session_cookies ={}
client = Qkhanh("</>", "</>", imei, session_cookies)
client.listen(run_forever=True)
